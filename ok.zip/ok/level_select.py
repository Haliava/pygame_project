import additional_functions
import settings
import pygame
import sys

'''pygame.init()
screen = pygame.display.set_mode((settings.WIDTH, settings.HEIGHT))
buttons = pygame.sprite.Group()
clock = pygame.time.Clock()


def level_select():
    for elem in settings.LEVELS:
        

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if start_button.rect.collidepoint(event.pos):
                    terminate()
                elif settings_button.rect.collidepoint(event.pos):
        buttons.update()
        pygame.display.flip()
        clock.tick(60)


level_select()'''
